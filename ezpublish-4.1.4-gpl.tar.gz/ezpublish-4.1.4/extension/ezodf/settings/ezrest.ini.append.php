<?php /*

[RESTSettings]
HandlerList[]=eZRESTODFHandler

*/ ?>
