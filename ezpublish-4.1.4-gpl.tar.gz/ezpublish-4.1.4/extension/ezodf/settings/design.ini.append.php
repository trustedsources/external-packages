<?php /* #?ini charset="iso-8859-1"?

# eZ Publish configuration file for designs
[ExtensionSettings]
DesignExtensions[]=ezodf

*/ ?>
