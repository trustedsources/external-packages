<?php /* #?ini charset="iso-8859-1"?

[SiteAccessSettings]
AnonymousAccessList[]=odf/upload_import
AnonymousAccessList[]=odf/authenticate
AnonymousAccessList[]=odf/upload_export

[RoleSettings]
PolicyOmitList[]=odf/upload_import
PolicyOmitList[]=odf/authenticate
PolicyOmitList[]=odf/upload_export
PolicyOmitList[]=odf/ezodf_oo_client

[RegionalSettings]
TranslationExtensions[]=ezodf

*/ ?>
