UPDATE ezsite_data set value='4.1.0' WHERE name='ezpublish-version';
UPDATE ezsite_data set value='1' WHERE name='ezpublish-release';
