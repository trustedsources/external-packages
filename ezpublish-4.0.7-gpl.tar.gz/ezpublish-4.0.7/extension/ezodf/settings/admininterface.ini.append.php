<?php /* #?ini charset="iso-8859-1"?

[AdditionalMenuSettings]
ContextMenuTemplateArray[]=node/oocontextmenu.tpl
SubitemsContextMenuTemplateArray[]=node/oosubitemscontextmenu.tpl
SubMenuTemplateArray[]=node/oocontextsubmenu.tpl
*/ ?>
