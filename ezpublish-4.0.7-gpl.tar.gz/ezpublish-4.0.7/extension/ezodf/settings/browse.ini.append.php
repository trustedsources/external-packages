<?php /* #?ini charset="iso-8859-1"?

[OOPlace]
StartNode=content
SelectionType=single
ReturnType=NodeID

*/ ?>
