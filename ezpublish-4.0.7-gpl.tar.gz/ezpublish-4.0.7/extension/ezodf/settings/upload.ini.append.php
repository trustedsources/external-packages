<?php /* #?ini charset="iso-8859-1"?

[CreateSettings]

# Upload handler setting for stock 3.6
MimeUploadHandlerMap[application/vnd.oasis.opendocument.text]=ezopenofficeuploadhandler

MimeUploadHandlerMap[application/msword]=ezopenofficeuploadhandler
MimeUploadHandlerMap[application/rtf]=ezopenofficeuploadhandler

*/ ?>
