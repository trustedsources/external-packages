<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezurlaliasmigration

*/ ?>
