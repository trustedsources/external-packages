The translation.ts file in share/translations/untranslated/ can be used to create a new clean translation.
Simply create a new directory in share/translations (eg. share/translations/eng-US) and copy the file
inside it. After that you may translate the file using the linguist program from TrollTech.

More information online at: http://ez.no/developer/translations
