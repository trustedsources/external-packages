@TODO This document is no longer up to date. Bj�rn Dieding on 09/2009

=================================================
= ENLISH INFORMATION
= 
= this document describes the german translation
= proccess and is written in german.
=================================================

README zur deutschen Uebersetzung.
=================================================

VERSION
--------------
Version 0.1 (dieses Dokument) vom 29.04.2006


AUTOR
--------------
dis(at)ez(dot)no Dirk Schmedding


ZIEL
--------------
Dieses Dokument soll die Arbeit an der deutschen Dokumentation unterstuetzen.


ALLGEMEIN
--------------
Die deutsche Uebersetzung wird ueber den SVN pubsvn.ez.no verwaltet.
Es wird regelmaessig eine Version in den trunk von svn.ez.no uebertragen.
Die obsoleten Eintraege sind auf alle Faelle weiter zu pflegen,
damit die Uebersetzungen auch weiterhin fuer aeltere Versionen benutzt werden kann.


WOERTERBUCH
--------------
Das Woerterbuch >pharsebook.qph< dient der Verwendung einer einheitlichen 
Terminologie aller eZ publish spezifischen Begriffe.
Jeder Autor sollte auf die Verwendung der dort angegeben Begriffe achten.
Sollte ein Begriff dort nicht enthalten sein, sollte derjenige nach besten
Wissen und Gewissen dort einen Eintrag machen.


WER MACHT WAS
--------------
Die Datei >todo< enthaelt alle Kontexte, die noch nicht ueberarbeitet wurden.

Wird ein Kontext von einem Autor angegangen, uebertraegt er diesen in die
Datei >progress<. Zusaetzlich sollten Name und Datum angegeben werden.

Sind die arbeiten abgeschlossen, sollte der Eintrag in die Datei >done<
uebertragen werden. Fuer die Credits nicht den Namen vergessen.

Jeder sollte darauf achten, dass diese Dateien aktuell sind, damit keine Konflikte im
SVN entstehen oder Arbeit doppelt gemacht wird.

Damit nichts verloren geht:
Die Ausgabe von >wc -l todo done progress< sollte in der Summe 363 sein.
Dann sind noch alle Aufgaben vorhanden.


DISKUSSIONEN
--------------
Fuer alle Diskussionen rund um die deutsche Uebersetzung steht das Forum auf
ezpublish.de offen.
http://ezpublish.de/forum

