The flags included in this directory were created by Cedric "Zone" Grandemange
upon a special request from eZ Systems (http://www.ez.no). The flags were
created and delivered during September 2004.

By the way of this text file, Cedric "Zone" Grandemange gives all rights
and copyrights to eZ Systems. eZ Systems can use these flags within the
upcoming releases of their main product, eZ Publish. The flags can be
used by eZ Systems for both commercial and non-commercial purposes.
The flags themselves (the GIF files alone) can not be sold or distributed
to individuals or companies. There are only two ways these flags can be
used/distributed:

1) As a part of an eZ Publish distribution released by eZ Systems

2) As a part of an eZ Publish variant released under the professional license


Cedric'Zone'Grandemange
http://www.lezone.fr.st
zone@cegetel.net
