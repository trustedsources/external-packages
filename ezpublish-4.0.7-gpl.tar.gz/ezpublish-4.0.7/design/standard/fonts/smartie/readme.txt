
Thank you for downloading my font!
All fonts are totally free, whether it be for commercial purposes or not. I only ask that you send me an e-mail telling 
me how and where you used it. That's it!
If you want to redistribute my font, please include this readme text with it and a link to my page would just peachie. 
Thanks for taking time to read this!

Have a nice day.
-Ben
bbalvanz@kccinter.net

All images and fonts Copyright 1998 Font-a-licious Fonts. All Rights Reserved.