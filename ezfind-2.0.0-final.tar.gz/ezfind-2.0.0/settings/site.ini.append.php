<?php /*

[SearchSettings]
# eZ Find overload search settings.
ExtensionDirectories[]=ezfind
SearchEngine=ezsolr
SearchViewHandling=template

# Empty search is allowed by default for eZ Find, since it does not
# use extra resources compared to regular search.
AllowEmptySearch=enabled

[RegionalSettings]
TranslationExtensions[]=ezfind

*/ ?>
