<?php /*

[ModuleSettings]
ExtensionRepositories[]=ezfind

*/ ?>
